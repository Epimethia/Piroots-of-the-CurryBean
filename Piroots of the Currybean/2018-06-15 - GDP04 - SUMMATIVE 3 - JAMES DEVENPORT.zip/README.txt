CONTROLS
WASD to move the ship
Arrow keys to fire in their respective directions
Arrow key up/down and Enter to navigate through menu

GAMEPLAY FEATURES
ENEMIES
Big ship - wanders around. does not shoot
small ship - follows the player. shoots bullets.

PLAYER DIES IF HIT BY BULLETS. NO HEALTH

Pink Rink Powerup - Makes the player shoot a ring of bullets
Blue Pyramid Powerup - Makes the player and the player's bullets faster
Yellow Cube Powerup - Increases the player's fire rate