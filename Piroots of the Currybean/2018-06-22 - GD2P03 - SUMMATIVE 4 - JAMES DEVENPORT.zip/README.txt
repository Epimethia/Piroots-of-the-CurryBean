Piroots of the Currybeans
	-James Devenport

//IN MENUS
[Arrow Up]/[Arrow Down] to move through options
[Enter] to select option

//GAMEPLAY
[W]	Move the ship forward	
[A]	Move the ship left
[S]	Move the ship down
[D]	Move the ship right

[Arrow Up]		Shoot a bullet up
[Arrow Left]		Shoot a bullet left
[Arrow Down]		Shoot a bullet down
[Arrow Right]		Shoot a bullet right

//POWERUPS
[Pyramid]	Increases the speed of the player and its bullets
[Square]	Increases the fire rate of the player
[Donut]		Causes the player's fire to shoot 8 bullets radially